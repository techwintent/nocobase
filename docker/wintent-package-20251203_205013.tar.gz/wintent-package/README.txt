====================================================
  Wintent NocoBase 部署包（插件方案）
====================================================

📦 包含内容

  - docker-compose.yml            Docker 配置
  - apply-config-from-host.sh     Wintent 配置脚本
  - wintent-plugin/@wintent/      Wintent 插件 ⭐
  - init-files/wintent-logo.png   Logo 文件
  - deploy.sh                     一键部署脚本 ⭐

====================================================

🚀 部署步骤

1. 解压
   tar -xzf wintent-package-*.tar.gz
   cd wintent-package

2. 修改配置（可选）
   vi .env

3. 部署
   ./deploy.sh

4. 访问
   http://your-server-ip:13000
   admin@wintent.tech / admin123

====================================================

✨ 特性

  ✓ 使用官方 Docker 镜像
  ✓ 包含 Wintent 插件（CSS 修改）
  ✓ 自动应用品牌配置
  ✓ 部署包小巧（约 1MB）

====================================================
