import { Plugin } from '@nocobase/client';
import models from './models';

export class PluginConfigClient extends Plugin {
  async load() {
    this.flowEngine.registerModels(models);
    
    // 注入 Wintent 自定义 CSS 样式
    this.injectCustomStyles();
  }

  private injectCustomStyles() {
    const style = document.createElement('style');
    style.setAttribute('data-wintent-custom', 'true');
    style.textContent = `
      /* Wintent 自定义样式 */
      .ant-layout-sider-children {
        margin-inline-end: 0 !important;
      }

      /* 固定菜单中图标和标题的距离，防止当切换到紧凑模式后，图标和标题之间的距离过近 */
      .ant-menu-title-content .ant-pro-base-menu-inline-item-title,
      .ant-menu-title-content .ant-pro-base-menu-horizontal-item-title {
        gap: 8px !important;
      }

      /* 修复紧凑模式下且菜单收起时，菜单的高度不够的问题 */
      .ant-pro-base-menu-vertical-collapsed .ant-pro-base-menu-vertical-menu-item {
        height: auto !important;
      }
    `;
    document.head.appendChild(style);
    
    console.log('[Wintent] Custom CSS styles injected successfully');
  }
}

export default PluginConfigClient;
