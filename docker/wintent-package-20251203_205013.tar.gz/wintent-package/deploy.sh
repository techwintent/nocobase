#!/bin/bash

# Wintent 服务器部署脚本（插件方案）

set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo "================================================"
echo "  Wintent NocoBase 服务器部署"
echo "================================================"
echo ""

echo "步骤 1: 检查 Docker..."
if ! command -v docker-compose &> /dev/null; then
    echo "❌ docker-compose 未安装"
    exit 1
fi
echo -e "${GREEN}✓ Docker 环境正常${NC}"

echo ""
echo "步骤 2: 创建环境配置..."
if [ ! -f ".env" ]; then
    cp env.example .env
    echo -e "${GREEN}✓ .env 已创建${NC}"
    echo -e "${YELLOW}⚠️  请检查并修改 .env 中的密钥！${NC}"
else
    echo -e "${GREEN}✓ .env 已存在${NC}"
fi

echo ""
echo "步骤 3: 安装 Wintent 插件..."
if [ -d "wintent-plugin/@wintent" ]; then
    echo "复制 Wintent 插件到 NocoBase..."
    # 插件会在容器启动时自动挂载
    echo -e "${GREEN}✓ Wintent 插件已准备${NC}"
else
    echo -e "${YELLOW}⚠️  未找到 Wintent 插件${NC}"
fi

echo ""
echo "步骤 4: 启动 Docker 容器..."
docker-compose up -d
echo -e "${GREEN}✓ 容器已启动${NC}"

echo ""
echo "步骤 5: 等待 NocoBase 初始化（3 分钟）..."
echo "查看日志: docker-compose logs -f app"
echo ""
for i in {1..180}; do
    if docker-compose logs app 2>&1 | grep -q "Application started"; then
        echo ""
        echo -e "${GREEN}✓ NocoBase 已启动${NC}"
        break
    fi
    echo -n "."
    sleep 1
    if [ $((i % 30)) -eq 0 ]; then
        echo " $i 秒"
    fi
done
echo ""

echo ""
echo "步骤 6: 应用 Wintent 配置..."
if [ -f "apply-config-from-host.sh" ]; then
    ./apply-config-from-host.sh
else
    echo -e "${YELLOW}⚠️  配置脚本不存在，请手动配置${NC}"
fi

echo ""
echo "================================================"
echo -e "${GREEN}  🎉 部署完成！${NC}"
echo "================================================"
echo ""
echo "访问: http://your-server-ip:13000"
echo "登录: admin@wintent.tech / admin123"
echo ""
echo "如果 Logo 或主题未显示，刷新浏览器: Ctrl+Shift+R"
echo ""
